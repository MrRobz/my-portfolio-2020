------------------------------------------------------------------------------------------
**************************
Welkin Vertikalsa - Freshdesk Portal Theme
**************************

Welkin Vertikalsa is a simple vertical layout style portal theme for Freshdesk. It provides simple and user friendly layouts to easily find knowledge base articles in Freshdesk. It will provide an refreshing, friendly and positive experience for your users.

The Welkin Vertikalsa template will perfectly suit those websites that aim that aim to keep their support page simple and efficient. Fully responsive and Retina ready.

****************
What's Included:
****************

1. 1 stylesheet.txt file with CSS code
2. 15 text files for all the portal pages including Header, Footer and Page Layout
3. Image files used in the theme
4. Screenshots of the Welkin Vertikalsa theme

**********************
Instructions to Setup:
**********************

checkout https://support.freshdesk.com/support/solutions/articles/65021-getting-started-with-freshthemes

1. Change the the links in code/footer.txt file.
2. Change icons and images in code files.
3. Copy all the necessary code into the respective sections in Customize Portal page in Freshdesk. 
4. Copy content stylesheet.txt into Stylesheet tab input-box in Customize Portal page.
5. Replace the URLs of icons in Portal home with your own links. 
6. Upload your own logo in your Freshdesk account. 
7. Make sure your Solutions folders have a descriptions as they will appear in the home screen. 

That's it. Good luck!

-------------------------------------------------------------------------------------------